#!/bin/bash

sudo dpkg -b ./
